/*:
## Exercise - Variables
 
 Declare a variable `schooling` and set it to the number of years of school that you have completed. Print `schooling` to the console.
 */
var schooling = 12
print(schooling)

//:  Now imagine you just completed an additional year of school, and update the `schooling` variable accordingly. Print `schooling` to the console.
schooling += 1
print(schooling)

//:  Does the above code compile? Why is this different than trying to update a constant? Print your explanation to the console using the `print` function.
// when we update the constant it changes the value of the constant entirely but if we use the operator we js add smth in original constant
/*:
[Previous](@previous)  |  page 3 of 10  |  [Next: App Exercise - Step Count](@next)
 */
